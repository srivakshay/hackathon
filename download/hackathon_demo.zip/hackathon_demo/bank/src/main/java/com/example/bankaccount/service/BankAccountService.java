package com.example.bankaccount.service;

import com.example.bankaccount.entity.BankAccount;
import com.example.bankaccount.repository.BankAccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BankAccountService {

    @Autowired
    private BankAccountRepository bankAccountRepository;

    public BankAccount findByAccountNumber(String accountNumber) {
        return bankAccountRepository.findByAccountNumber(accountNumber);
    }

    public BankAccount updateAccountBalance(String accountNumber, double amount) {
        BankAccount account = bankAccountRepository.findByAccountNumber(accountNumber);
        account.setAccountBalance(account.getAccountBalance() + amount);
        return bankAccountRepository.save(account);
    }
}