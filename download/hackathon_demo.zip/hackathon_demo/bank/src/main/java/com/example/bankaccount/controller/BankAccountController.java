package com.example.bankaccount.controller;

import com.example.bankaccount.entity.BankAccount;
import com.example.bankaccount.service.BankAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/accounts")
public class BankAccountController {

    @Autowired
    private BankAccountService bankAccountService;

    @GetMapping("/{accountNumber}")
    public ResponseEntity<BankAccount> getBankAccount(@PathVariable String accountNumber) {
        BankAccount bankAccount = bankAccountService.findByAccountNumber(accountNumber);
        return ResponseEntity.ok(bankAccount);
    }

    @PutMapping("/{accountNumber}")
    public ResponseEntity<BankAccount> updateAccountBalance(@PathVariable String accountNumber, @RequestBody double amount) {
        BankAccount updatedAccount = bankAccountService.updateAccountBalance(accountNumber, amount);
        return ResponseEntity.ok(updatedAccount);
    }
}
