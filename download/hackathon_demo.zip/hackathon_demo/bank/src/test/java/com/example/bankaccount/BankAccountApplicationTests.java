package com.example.bankaccount;

import com.example.bankaccount.entity.BankAccount;
import com.example.bankaccount.repository.BankAccountRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
class BankAccountApplicationTests {

    @Autowired
    private BankAccountRepository bankAccountRepository;

    @Test
    void testFindByAccountNumber() {
        String accountNumber = "123456789";
        BankAccount account = bankAccountRepository.findByAccountNumber(accountNumber);
        assertNotNull(account);
        assertEquals(accountNumber, account.getAccountNumber());
    }

    @Test
    void testUpdateAccountBalance() {
        String accountNumber = "123456789";
        BankAccount account = bankAccountRepository.findByAccountNumber(accountNumber);
        double initialBalance = account.getAccountBalance();
        double amount = 1000.0;
        account.setAccountBalance(initialBalance + amount);
        BankAccount updatedAccount = bankAccountRepository.save(account);
        assertEquals(initialBalance + amount, updatedAccount.getAccountBalance());
    }
}
