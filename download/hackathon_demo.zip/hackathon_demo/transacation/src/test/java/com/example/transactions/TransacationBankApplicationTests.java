package com.example.transactions;

import com.example.transactions.entity.Transaction;
import com.example.transactions.repository.TransactionRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
class TransactionApplicationTests {

    @Autowired
    private TransactionRepository transactionRepository;

    @Test
    void testCreateTransaction() {
        Transaction transaction = new Transaction();
        transaction.setAccountNumber("123456789");
        transaction.setCustomerId("customer1");
        transaction.setTransactionMemo("Test transaction");

        Transaction createdTransaction = transactionRepository.save(transaction);
        assertNotNull(createdTransaction);
        assertNotNull(createdTransaction.getId());
    }
}
